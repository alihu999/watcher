import 'package:flutter/material.dart';

class AppColors {
  static Color firstColors = const Color(0xff0a0352);
  static Color secondColors = const Color(0xffce0505);
}
